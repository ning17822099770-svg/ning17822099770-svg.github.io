# 个人学术主页模板 · 使用说明

这份模板保留了原主页的浅绿配色、衬线大标题、双栏区块、项目与论文排版、手机菜单和跟随系统的深色模式。姓名、照片、履历、论文、联系方式和简历附件已经替换成示例。

这是 HTML + CSS + JavaScript 静态网页，不需要 Node.js、npm、React、数据库或构建命令。网站正文默认是英文，源码中有中文修改提示。也可以直接把正文改成中文。

## 1. 先打开看看

1. 完整解压 ZIP，不要只把 index.html 从压缩包中拖出来。
2. 进入解压后的文件夹，双击 index.html。
3. 用 VS Code、文本编辑器或 GitHub 在线编辑器修改文件。不要用 Word 编辑 HTML。
4. 保存后刷新浏览器即可看到修改。

如果自定义的浏览器安全设置阻止本地脚本，可在该目录运行 `python3 -m http.server 8000`（Windows 也可用 `py -m http.server 8000`），然后访问 http://localhost:8000 。

## 2. 文件分别做什么

| 文件 | 用途 |
|---|---|
| index.html | 修改姓名、简介、项目、论文、教育、联系方式等正文 |
| styles.css | 修改颜色、字体、宽度、间距和手机排版 |
| main.js | 手机导航菜单、Esc 关闭菜单和当前区块高亮 |
| assets/profile-placeholder.svg | 默认头像占位图 |
| assets/gallery-1-placeholder.svg、gallery-2-placeholder.svg | 两张生活照片占位图 |
| assets/favicon.svg | 浏览器标签上的 YN 图标，可改为自己的姓名缩写 |
| assets/cv.pdf、resume.pdf | 示例占位 PDF，请替换成自己的真实文件 |
| .nojekyll | 让 GitHub Pages 直接发布静态文件 |

## 3. 按顺序改成自己的内容

### 姓名和身份

在 index.html 中搜索 `Your Name`、`Your University`、`[Your`，逐处替换。导航、首页、作者名、页脚和浏览器标题都有姓名。

页面最上方还需修改 `<title>` 和 `<meta name="description">`，这是浏览器标签和搜索引擎摘要。若页面主要使用中文，可把 `<html lang="en">` 改成 `<html lang="zh-CN">`。

### 照片

1. 把自己的照片放进 assets 文件夹，例如 profile.jpg。
2. 在 index.html 中将 `src="assets/profile-placeholder.svg"` 改为 `src="assets/profile.jpg"`。
3. 把相邻的 alt 改成自己的照片说明。
4. 生活照片采用同样方法。文件名建议用英文字母、数字和短横线。

头像按正方形裁切，生活照片按 4:5 裁切。需要调整显示位置时，在 styles.css 中修改 object-position。占位 SVG 是模板示意图，可以在替换后删除。

### 简历

将自己的 PDF 重命名为 cv.pdf、resume.pdf，替换 assets 中同名文件，并把首页两个按钮的 download 文件名改成自己的姓名。示例 PDF 只用于演示链接，不包含任何人的真实履历。

只有一份简历时，删除另一个 `<a class="button ...">...</a>` 按钮即可。

### 社交链接和邮箱

搜索并替换以下示例：首页和 Contact 两处都需要改。

| 当前示例 | 替换成 |
|---|---|
| hello@example.com | 本人公开邮箱；可见文字和 mailto: 地址都要修改 |
| https://github.com/ | 本人的 GitHub 主页或对应项目仓库 |
| https://scholar.google.com/ | 本人的 Scholar 作者主页 |
| https://www.linkedin.com/ | 本人的 LinkedIn 主页 |

示例社交链接现在指向各平台首页。没有对应账号时，直接删除那条链接，不需要保留占位项。

### 研究和项目

每个项目使用一个 `<article class="project"> ... </article>`。复制完整条目即可增加项目，删除完整条目即可减少。

建议每个项目回答：解决什么问题；自己具体做了什么；使用什么工具；如何评估，以及有哪些可验证的成果。把缩写第一次出现时写清楚。

项目区里的 Publication details 和 Code details 指向本页示例条目。有真实论文或代码网址后，可以换成具体外部链接。新窗口打开的链接保留 `target="_blank" rel="noopener noreferrer"`。

### 论文、教学和教育

论文按期刊、会议、准备中排列。复制完整的 `article.publication` 添加条目；只有真实已接收论文才使用 Accepted 标记；请根据实际状态修改或删除标记。

没有论文、教学或其他经历时，可以删除对应整个 `<section ...>...</section>`；同时删除导航中指向该区块的链接。例如删除 Publications 时，也删除 `<a href="#publications">Publications</a>`。其他区块中指向已删除内容的链接也应删除或更新。

所有方括号内容均为提示文字，发布前替换或删除。日期、成绩、奖项、数量和成果都按本人真实情况填写。

## 4. 调整颜色

styles.css 最上面的 `:root` 是浅色主题，下面的 `@media(prefers-color-scheme:dark)` 是深色主题。

```css
--bg: #f3f6f4;          /* 页面底色 */
--surface: #ffffff;     /* 表面色 */
--ink: #14201c;         /* 正文色 */
--accent: #0e6d5b;      /* 主题色 */
--accent-strong: #084f42;/* 深色主题文字/按钮 */
--accent-soft: #d8ebe5; /* 标签底色 */
```

字体使用 Google Fonts 的 IBM Plex Sans 和 Newsreader。网络不可用时会自动使用 Arial、Georgia 等本地备选字体，不影响正文和导航。

## 5. 免费发布到自己的 GitHub 域名

以下是“新建个人主页”的流程，使用你自己的 GitHub 账号。若同名仓库已经存在，先查看和备份其中内容，再决定如何合并。

1. 新建 Public 仓库，名称为 `你的GitHub用户名.github.io`。例如用户名 alice，仓库就是 alice.github.io。
2. 解压本模板，把模板文件夹**里面的文件和 assets 文件夹**上传到仓库根目录。不要上传 ZIP，也不要把整个模板文件夹作为额外一层上传；打开仓库就应该能看到 index.html、styles.css、main.js 和 assets。
3. 使用默认 main 分支提交文件。若仓库实际使用其他分支，以实际分支为准。
4. 打开仓库 **Settings → Pages**。
5. **Build and deployment → Source** 选择 **Deploy from a branch**。
6. Branch 选择 **main**，目录选择 **/(root)**，点击 Save。
7. 等待部署完成，访问 `https://你的GitHub用户名.github.io/`。GitHub 提示发布变更可能需要最多约10分钟。

本模板是普通静态 HTML，不需要配置 Jekyll、_config.yml 或自定义 GitHub Actions。保留 .nojekyll 即可；如果网页上传没有带上这个文件，也可以通过 Add file → Create new file 新建 `.nojekyll`，写入一行空白并提交。

部署以后，在 GitHub 修改 index.html / styles.css 或替换图片和 PDF，点击 Commit changes，Pages 会重新发布。看不到更新时先确认 Actions 中部署成功，再强制刷新页面。

官方说明（2026-10-29核对）：
- https://docs.github.com/en/pages/quickstart
- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## 6. 发布前最后检查

- 姓名、学校、邮箱、社交地址和页脚都已替换。
- 方括号示例内容与不需要的区块已删除或改写。
- 首页两份 PDF 已换成本人文件，并实际点击下载检查。
- 头像、生活照片和对应 alt / caption 已更新。
- 每篇论文、每个项目的链接都指向对应页面。
- 在手机宽度打开 Menu，确认导航正常，正文无横向溢出。
- 首页介绍、简历、LinkedIn 中的重要日期保持一致。

网站不包含表单后端或访问统计。如果以后需要这些功能，再单独添加即可。
